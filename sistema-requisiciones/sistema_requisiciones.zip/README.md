# Sistema de gestion de requisiciones
Sistema que permite gestionar las requisiciones, proyectos y usuarios de una universidad

## Desarrollado con
* HTML, CSS, JS
* BOOTSTRAP
* LARAVEL
* MySQL

## Contribuidores
* Hernández Ortega Daniel Mitchel
