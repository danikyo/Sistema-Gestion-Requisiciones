<head><link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet"></head>

<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="panel panel-default">
		<div class="panel-heading">
			Proyectos 
		</div>

		<form class="navbar-form navbar-left pull-right" role="search" action="consultarProyecto" method="GET">
			<div class="form-group">
				<input name="name" type="text" class="form-control" placeholder="nombre o código...">
			</div>
			<button class="btn btn-default" type="submit">Buscar</button>
		</form>

		<div class="panel-body">
			<div class="col-md-12">
				<table id="activityTable" class="table .table-striped">
					<tr>
						<th>IDCA</th>
						<th>Nombre de Proyecto</th>
						<th>Monto</th>
						<th>Fecha Vigencia</th>
						<th>Opción</th>
					</tr>
					<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td class="text-center">
							<?php echo e($project->id); ?>

						</td>
						<td>
							<?php echo e($project->name); ?>

						</td>
						<td>
							<?php echo e($project->currentAmount); ?>

						</td>
						<td>
							<?php echo e($project->startDate); ?>

						</td>
						<td class="text-center">
							<a href="proyecto=<?php echo e($project->id); ?>" class="btn btn-success"><span title="Editar" class="glyphicon glyphicon-pencil"></span></div>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</table>
				<?php echo $projects->render(); ?>

			</div>
				
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>