<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="panel panel-default">
			<div class="panel-body">
				<div class="row">
					<img src="/images/headerProject.png" class="img-responsive center-block" alt="Imagen responsive">
					<br><br>
				</div>

				<div class="row text-center">
					<strong style="font-size: 3vh">Dictamen Aprobado</strong>
				</div>

				<div class="row">
					<div class="table-responsive col-md-6 col-md-offset-3">
						<table class="table table-condensed">
							<tr>
								<th class="text-center" width="200">Institución</th>
								<td >Universidad Politénica de la Zona Metropolitana de Guadalajara</td>
							</tr>
							<tr>
								<th class="text-center" width="200">Nombre del Cuerpo Académico</th>
								<td><?php echo e($project->caname); ?></td>
							</tr>
							<tr>
								<th class="text-center" width="200">IDCA</th>
								<td> <?php echo e($project->id); ?> </td>
							</tr>
							<tr>
								<th class="text-center" width="200">CLAVE</th>
								<td> <?php echo e($project->clave); ?> </td>
							</tr>
							<tr>
								<th class="text-center" width="200">Nombre del Proyecto</th>
								<td> <?php echo e($project->name); ?> </td>
							</tr>
							<tr>
								<th class="text-center" width="200">Vigencia del Proyecto</th>
								<td> <?php echo e($project->startDate); ?> - <?php echo e($project->endDate); ?> </td>
							</tr>
						</table>
					</div>
				</div>

				<div class="row">
					<img src="/images/dictamenProject.png" class="img-responsive center-block" alt="Imagen responsive">
				</div>

				<?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="row">
					<div class="col-md-12">
						<div class="panel panel-default">
							<div class="panel-heading text-center"> <h4 style="font-size: 3vh;"> Actividad <?php echo e($activity->id); ?> </h4> </div>

							<div class="panel-body">
								<div class="row container">
									<label for="description" style="font-size: 3vh;"><strong>Descripción</strong></label>
									<p id="description" style="font-size: 3vh;"><?php echo e($activity->description); ?></p>
									<label for="" style="font-size: 3vh;"><strong>Integrantes</strong></label>
								</div>
								<div class="table-responsive col-md-12">
									<table class="table table-bordered">
										<tr>
											<th>Nombre</th>
										</tr>
										<?php $__currentLoopData = $activity->users()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td><?php echo e($u->name); ?></td>
										</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</table>
								</div>
								<div class="row container">
									<label for="" style="font-size: 3vh;"><strong>Recursos</strong></label>
								</div>
								<div class="table-responsive col-md-12">
									<table class="table table-bordered">
										<tr>
											<th>ID</th>
											<th>Tipo de Recurso</th>
											<th>Descripción</th>
											<th>Monto Aprobado</th>
										</tr>
										<?php $__currentLoopData = $activity->resources()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td>
												<?php echo e($r->id); ?>

											</td>
											<td>
												<?php echo e($r->type); ?>

											</td>
											<td>
												<table class="table table-bordered">
													<?php $__currentLoopData = $r->products()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<tr>
														<td><?php echo e($p->name); ?></td>
													</tr>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</table>
											</td>
											<td>
												<table class="table table-bordered">
													<?php $__currentLoopData = $r->products()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<tr>
														<td>$<?php echo e($p->price); ?></td>
													</tr>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</table>
											</td>
										</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</table>
								</div>
							</div>
						</div>
						
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				<div class="row">
					<div class="table-responsive col-md-6 col-md-offset-3">
						<table class="table table-condensed">
							<tr>
								<th class="text-center" width="200">Monto Total Aprobado al Cuerpo Académico</th>
								<td class="text-center" style="font-size: 3vh"> $<?php echo e($project->currentAmount); ?> </td>
							</tr>
						</table>
					</div>
				</div>

				<div class="row">
					<div class="row">			
						<img src="/images/footerProject.png" class="img-responsive center-block" alt="Imagen responsive">
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>